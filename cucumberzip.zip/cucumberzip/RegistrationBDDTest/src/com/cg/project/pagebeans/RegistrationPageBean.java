package com.cg.project.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class RegistrationPageBean {
	@FindBy(how=How.NAME,name="login_field")
	private WebElement userId;

	@FindBy(how=How.NAME,name="password")
	private WebElement password;

	@FindBy(how=How.NAME,name="submit")
	private WebElement submitbtn;

	public RegistrationPageBean() {
		super();
	}


	public void setUserId(WebElement userId) {
		this.userId = userId;
	}

	public void setPassword(WebElement password) {
		this.password = password;
	}

	public String getUserId() {
		return userId.getAttribute("value");
	}

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}



	public WebElement getSubmitbtn() {
		return submitbtn;
	}

	public void setSubmitbtn(WebElement submitbtn) {
		this.submitbtn = submitbtn;
	}


}
