package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.github.pagebeans.LoginPage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GithubOperations {
	private WebDriver driver;
	private LoginPage loginPage;
	
	@Before
	public void setupStepEnv() {
	System.setProperty("webdriver.chrome.driver", "D:\\3000155_Debojyoti_Basu\\BDDCucumberSelenium\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();	
	}
	@Given("^User is on the Github login page$")
	public void user_is_on_the_Github_login_page() throws Throwable {
	   driver =new ChromeDriver();
	   driver.get("https://github.com/login");
	   loginPage=PageFactory.initElements(driver,LoginPage.class);
	}
	@When("^user give Invalid username And password$")
	public void user_give_Invalid_username_And_password() throws Throwable {
		  loginPage.setUsername("Debojyoti.123");
		   loginPage.setPassword("asdfg");
		   loginPage.clickSignIn();   
	}

	@Then("^'Invalid Username' message should display$")
	public void invalid_Username_message_should_display() throws Throwable {
	   String expectedErrorMessage="Incorrect username or password";
	  Assert.assertEquals(expectedErrorMessage,loginPage.getActualErrorMessage());
	}


	@When("^user give valid username And password$")
	public void user_wants_to_give_valid_username_And_password() throws Throwable {
		   loginPage.setUsername("Debojyoti1234");
		   loginPage.setPassword("Biki@1996");
		   loginPage.toString();
	}

	@Then("^User should successfully login$")
	public void user_should_successfully_login() throws Throwable {
	    String actualTitle=driver.getTitle();
	    String expectedTitle="Debojyoti1234";
	    Assert.assertEquals(expectedTitle,actualTitle);
	}
	@After
	public void tearDownStepEnv() {
		driver.close();
	}
}
